window.onload=function(){
	passwordobj=document.getElementById('password');
	usernameobj=document.getElementById('username');

	window.onblur=function(){
	x=passwordobj.value;
	y=usernameobj.value;

	if(x==123 && y==123){
		alert('密码输入成功');
		location='zy.html';
	}
}
}