window.onload=function(){
	setInterval(function(){
	sid=document.getElementById('sid')
	dobj=new Date();
	years=dobj.getFullYear();
	hour=dobj.getHours();      
	minute=dobj.getMinutes();  
	second=dobj.getSeconds();
	if(second<10){
		second="0"+second;
	}
	time=years+":"+hour+":"+minute+":"+second;
	sid.innerHTML=time;

},0);
}
